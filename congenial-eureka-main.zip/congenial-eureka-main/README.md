# congenial-eureka

A simple command line to-do app. It's only using a text file for storage so no need for a database. It's really meant for daily usage, when you're done for the day delete the file then go again. 

To add an item:
`python3 to-do.py add --item-text "cook dinner"`

To mark item as done
`python3 to-do.py done --item-number 2`

To list
`python3 to-do.py list`
